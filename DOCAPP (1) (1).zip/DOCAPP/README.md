# edoc-echanneling

  1.Admin
  
  
    Admin can add doctors,edit doctors, delete doctors;
    
    Schedule new doctors sessions,remove sessions;
    
    View patients details;
    
    View booking of patients;
    
    

    
 
 
  2.Doctors
  
  
    View their Appointment;
    
    view their scheduled sessions;
    
    view details of patients;
    
    delete account;
    
    edit account settings;
    

    
  3.Patiens(Clients)
  
  
    make appointment online;
    
    create accounts themslves;
    
    view their old booking;
    
    delete account;
    
    edit account settings;
    
    
  
    
If you are Admin,doctor or patient ,only have one page to login 

  
-----------------------------------------------



DATABASE NAME: 'edoc'

# BUILDIN USER ACCOUNTS OF THIS PROJECT

ADMIN EMAIL:		admin@edoc.com

ADMNIN PASSWORD:	123


DOCTOR EMAIL:		doctor@edoc.com

DOCTOR PASSWORD:	123


PATIENT EMAIL:		patient@edoc.com

PATIENT PASSWORD:	123






